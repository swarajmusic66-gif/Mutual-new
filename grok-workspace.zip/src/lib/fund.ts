export const CURRENCIES = [
  { code: "INR", label: "₹ INR", locale: "en-IN" },
  { code: "USD", label: "$ USD", locale: "en-US" },
  { code: "EUR", label: "€ EUR", locale: "de-DE" },
  { code: "GBP", label: "£ GBP", locale: "en-GB" },
] as const;

export type CurrencyCode = (typeof CURRENCIES)[number]["code"];
export type Mode = "sip" | "lumpsum" | "swp" | "goal";

export type FundInput = {
  mode: Mode;
  currency: CurrencyCode;
  sip: number;
  lumpsum: number;
  corpus: number;
  withdrawal: number;
  target: number;
  rate: number;
  years: number;
  stepUp: number;
  inflationOn: boolean;
  inflation: number;
};

export type YearPoint = {
  year: number;
  invested: number;
  value: number;
  withdrawn: number;
  partial: boolean;
};

export type Projection = {
  mode: Mode;
  invested: number;
  value: number;
  withdrawn: number;
  growth: number;
  months: number;
  depleted: boolean;
  monthlySip: number | null;
  realValue: number;
  points: YearPoint[];
};

type Preset = {
  sip: number;
  sipMax: number;
  lumpsum: number;
  lumpsumMax: number;
  corpus: number;
  corpusMax: number;
  withdrawal: number;
  withdrawalMax: number;
  target: number;
  targetMax: number;
  step: number;
};

export const PRESETS: Record<CurrencyCode, Preset> = {
  INR: {
    sip: 5000,
    sipMax: 100000,
    lumpsum: 100000,
    lumpsumMax: 5000000,
    corpus: 2500000,
    corpusMax: 20000000,
    withdrawal: 20000,
    withdrawalMax: 200000,
    target: 10000000,
    targetMax: 50000000,
    step: 500,
  },
  USD: {
    sip: 200,
    sipMax: 5000,
    lumpsum: 10000,
    lumpsumMax: 250000,
    corpus: 100000,
    corpusMax: 2000000,
    withdrawal: 800,
    withdrawalMax: 10000,
    target: 500000,
    targetMax: 5000000,
    step: 25,
  },
  EUR: {
    sip: 200,
    sipMax: 5000,
    lumpsum: 10000,
    lumpsumMax: 250000,
    corpus: 100000,
    corpusMax: 2000000,
    withdrawal: 800,
    withdrawalMax: 10000,
    target: 500000,
    targetMax: 5000000,
    step: 25,
  },
  GBP: {
    sip: 150,
    sipMax: 4000,
    lumpsum: 8000,
    lumpsumMax: 200000,
    corpus: 80000,
    corpusMax: 1500000,
    withdrawal: 600,
    withdrawalMax: 8000,
    target: 400000,
    targetMax: 4000000,
    step: 25,
  },
};

export const DEFAULT_INPUT: FundInput = {
  mode: "sip",
  currency: "INR",
  ...pickAmounts("INR"),
  rate: 12,
  years: 10,
  stepUp: 0,
  inflationOn: false,
  inflation: 6,
};

function pickAmounts(code: CurrencyCode) {
  const p = PRESETS[code];
  return {
    sip: p.sip,
    lumpsum: p.lumpsum,
    corpus: p.corpus,
    withdrawal: p.withdrawal,
    target: p.target,
  };
}

export function withCurrency(input: FundInput, currency: CurrencyCode): FundInput {
  return { ...input, currency, ...pickAmounts(currency) };
}

export function resetInput(currency: CurrencyCode, mode: Mode): FundInput {
  return { ...DEFAULT_INPUT, currency, mode, ...pickAmounts(currency) };
}

const HARD_MAX = 1_000_000_000_000;

export function clampInput(input: FundInput): FundInput {
  return {
    ...input,
    sip: clamp(input.sip, 0, HARD_MAX),
    lumpsum: clamp(input.lumpsum, 0, HARD_MAX),
    corpus: clamp(input.corpus, 0, HARD_MAX),
    withdrawal: clamp(input.withdrawal, 0, HARD_MAX),
    target: clamp(input.target, 0, HARD_MAX),
    rate: clamp(input.rate, 0, 30),
    years: Math.round(clamp(input.years, 1, 40)),
    stepUp: clamp(input.stepUp, 0, 25),
    inflation: clamp(input.inflation, 0, 15),
  };
}

function clamp(n: number, min: number, max: number) {
  if (!Number.isFinite(n)) return min;
  return Math.min(max, Math.max(min, n));
}

function monthlyRate(annualPct: number) {
  return annualPct / 100 / 12;
}

function roundMoney(n: number) {
  return Math.round(n);
}

/** SIP: contribution at the start of the month, then one month of growth. */
export function simulateSip(monthly: number, annualPct: number, years: number, stepUpPct: number) {
  const i = monthlyRate(annualPct);
  const months = years * 12;
  let value = 0;
  let invested = 0;
  const points: YearPoint[] = [{ year: 0, invested: 0, value: 0, withdrawn: 0, partial: false }];

  for (let m = 1; m <= months; m++) {
    const yearIndex = Math.floor((m - 1) / 12);
    const pmt = monthly * (1 + stepUpPct / 100) ** yearIndex;
    value = (value + pmt) * (1 + i);
    invested += pmt;
    if (m % 12 === 0) {
      points.push({
        year: m / 12,
        invested: roundMoney(invested),
        value: roundMoney(value),
        withdrawn: 0,
        partial: false,
      });
    }
  }

  return { invested, value, points };
}

/** Lump sum: monthly compounding, no new contributions. */
export function simulateLumpsum(principal: number, annualPct: number, years: number) {
  const i = monthlyRate(annualPct);
  const months = years * 12;
  let value = principal;
  const points: YearPoint[] = [
    {
      year: 0,
      invested: roundMoney(principal),
      value: roundMoney(principal),
      withdrawn: 0,
      partial: false,
    },
  ];

  for (let m = 1; m <= months; m++) {
    value *= 1 + i;
    if (m % 12 === 0) {
      points.push({
        year: m / 12,
        invested: roundMoney(principal),
        value: roundMoney(value),
        withdrawn: 0,
        partial: false,
      });
    }
  }

  return { invested: principal, value, points };
}

/**
 * Withdrawal: balance grows for the month, then the withdrawal is taken.
 * Stops early if the balance cannot cover a full withdrawal.
 */
export function simulateSwp(corpus: number, withdrawal: number, annualPct: number, years: number) {
  const i = monthlyRate(annualPct);
  const months = years * 12;
  let value = corpus;
  let withdrawn = 0;
  let depleted = false;
  let monthsRun = 0;
  const points: YearPoint[] = [
    {
      year: 0,
      invested: roundMoney(corpus),
      value: roundMoney(corpus),
      withdrawn: 0,
      partial: false,
    },
  ];

  for (let m = 1; m <= months; m++) {
    value *= 1 + i;
    const take = Math.min(Math.max(withdrawal, 0), Math.max(value, 0));
    value -= take;
    withdrawn += take;
    const short = withdrawal > 0 && take + 0.005 < withdrawal;
    if (value <= 0.005 || short) {
      value = 0;
      depleted = true;
    }
    monthsRun = m;
    if (m % 12 === 0 || depleted) {
      points.push({
        year: Math.ceil(m / 12),
        invested: roundMoney(corpus),
        value: roundMoney(value),
        withdrawn: roundMoney(withdrawn),
        partial: depleted && m % 12 !== 0,
      });
    }
    if (depleted) break;
  }

  return { invested: corpus, value, withdrawn, depleted, monthsRun, points };
}

export function requiredSip(target: number, annualPct: number, years: number, stepUpPct: number) {
  if (target <= 0) return 0;
  let lo = 0;
  let hi = target;
  for (let k = 0; k < 80; k++) {
    const mid = (lo + hi) / 2;
    if (simulateSip(mid, annualPct, years, stepUpPct).value >= target) hi = mid;
    else lo = mid;
  }
  return Math.ceil(hi);
}

export function project(raw: FundInput, rateOverride?: number): Projection {
  const input = clampInput(raw);
  const rate = rateOverride ?? input.rate;
  const inflation = input.inflationOn ? input.inflation : 0;

  let invested = 0;
  let value = 0;
  let withdrawn = 0;
  let months = input.years * 12;
  let depleted = false;
  let monthlySip: number | null = null;
  let points: YearPoint[] = [];

  if (input.mode === "sip") {
    const sim = simulateSip(input.sip, rate, input.years, input.stepUp);
    invested = sim.invested;
    value = sim.value;
    points = sim.points;
  } else if (input.mode === "lumpsum") {
    const sim = simulateLumpsum(input.lumpsum, rate, input.years);
    invested = sim.invested;
    value = sim.value;
    points = sim.points;
  } else if (input.mode === "swp") {
    const sim = simulateSwp(input.corpus, input.withdrawal, rate, input.years);
    invested = sim.invested;
    value = sim.value;
    withdrawn = sim.withdrawn;
    months = sim.monthsRun;
    depleted = sim.depleted;
    points = sim.points;
  } else {
    monthlySip = requiredSip(input.target, rate, input.years, input.stepUp);
    const sim = simulateSip(monthlySip, rate, input.years, input.stepUp);
    invested = sim.invested;
    value = sim.value;
    points = sim.points;
  }

  invested = roundMoney(invested);
  value = roundMoney(value);
  withdrawn = roundMoney(withdrawn);
  const growth = value + withdrawn - invested;
  const realValue = roundMoney(value / (1 + inflation / 100) ** input.years);

  return {
    mode: input.mode,
    invested,
    value,
    withdrawn,
    growth,
    months,
    depleted,
    monthlySip,
    realValue,
    points,
  };
}

export function scenarioRates(rate: number): number[] {
  const current = Math.round(rate * 10) / 10;
  const set = new Set<number>([8, current, 15]);
  return [...set].sort((a, b) => a - b);
}

export function formatMoney(value: number, code: CurrencyCode, opts?: { compact?: boolean }) {
  const cur = CURRENCIES.find((c) => c.code === code) ?? CURRENCIES[0];
  const sign = value < 0 ? "-" : "";
  const abs = Math.abs(value);

  if (opts?.compact) {
    const scaled = compactParts(abs, code);
    if (scaled) {
      const num = new Intl.NumberFormat(cur.locale, {
        minimumFractionDigits: 0,
        maximumFractionDigits: scaled.digits,
      }).format(scaled.n);
      return `${sign}${symbol(code)}${num}${scaled.suffix}`;
    }
  }

  return new Intl.NumberFormat(cur.locale, {
    style: "currency",
    currency: code,
    maximumFractionDigits: 0,
  }).format(value);
}

function symbol(code: CurrencyCode) {
  if (code === "INR") return "₹";
  if (code === "USD") return "$";
  if (code === "EUR") return "€";
  return "£";
}

function compactParts(abs: number, code: CurrencyCode) {
  const units =
    code === "INR"
      ? [
          { v: 1e7, s: " Cr" },
          { v: 1e5, s: " L" },
        ]
      : [
          { v: 1e9, s: "B" },
          { v: 1e6, s: "M" },
          { v: 1e3, s: "K" },
        ];
  for (const u of units) {
    if (abs >= u.v) {
      const n = abs / u.v;
      const digits = n >= 100 ? 0 : n >= 10 ? 1 : 1;
      return { n, suffix: u.s, digits };
    }
  }
  return null;
}

export function formatPct(n: number) {
  const rounded = Math.round(n * 10) / 10;
  return Number.isInteger(rounded) ? `${rounded}%` : `${rounded.toFixed(1)}%`;
}

export function formatDuration(months: number) {
  const safe = Math.max(0, Math.round(months));
  const y = Math.floor(safe / 12);
  const m = safe % 12;
  const parts: string[] = [];
  if (y) parts.push(`${y} ${y === 1 ? "year" : "years"}`);
  if (m) parts.push(`${m} ${m === 1 ? "month" : "months"}`);
  return parts.join(" ") || "0 months";
}

export function formatMultiple(value: number, invested: number) {
  if (invested <= 0) return "—";
  const mult = value / invested;
  const digits = mult >= 10 ? 1 : 2;
  return `${mult.toFixed(digits)}×`;
}

export function summaryText(input: FundInput, result: Projection) {
  const c = input.currency;
  const lines = ["Mutual fund estimate (steady return, for learning)"];
  if (input.mode === "sip") {
    lines.push(`Monthly SIP: ${formatMoney(input.sip, c)}`);
    if (input.stepUp > 0) lines.push(`Yearly step-up: ${formatPct(input.stepUp)}`);
  } else if (input.mode === "lumpsum") {
    lines.push(`Lump sum: ${formatMoney(input.lumpsum, c)}`);
  } else if (input.mode === "swp") {
    lines.push(`Starting amount: ${formatMoney(input.corpus, c)}`);
    lines.push(`Monthly withdrawal: ${formatMoney(input.withdrawal, c)}`);
  } else {
    lines.push(`Target: ${formatMoney(input.target, c)}`);
    lines.push(`Monthly SIP needed: ${formatMoney(result.monthlySip ?? 0, c)}`);
    if (input.stepUp > 0) lines.push(`Yearly step-up: ${formatPct(input.stepUp)}`);
  }
  lines.push(`Assumed return: ${formatPct(input.rate)} a year`);
  lines.push(`Time: ${input.years} ${input.years === 1 ? "year" : "years"}`);
  lines.push(`Money in: ${formatMoney(result.invested, c)}`);
  if (result.withdrawn > 0) lines.push(`Withdrawn: ${formatMoney(result.withdrawn, c)}`);
  lines.push(`Estimated value: ${formatMoney(result.value, c)}`);
  lines.push(`Estimated growth: ${formatMoney(result.growth, c)}`);
  if (input.mode === "swp" && result.depleted) {
    lines.push(`Withdrawals last about ${formatDuration(result.months)}.`);
  }
  lines.push("Not a promise. Real mutual fund returns move up and down.");
  return lines.join("\n");
}

const MODES: Mode[] = ["sip", "lumpsum", "swp", "goal"];

export function parseStored(raw: unknown): FundInput | null {
  if (!raw || typeof raw !== "object") return null;
  const o = raw as Partial<FundInput>;
  if (!o.mode || !MODES.includes(o.mode)) return null;
  if (!o.currency || !CURRENCIES.some((c) => c.code === o.currency)) return null;
  return clampInput({
    mode: o.mode,
    currency: o.currency,
    sip: num(o.sip),
    lumpsum: num(o.lumpsum),
    corpus: num(o.corpus),
    withdrawal: num(o.withdrawal),
    target: num(o.target),
    rate: num(o.rate),
    years: num(o.years),
    stepUp: num(o.stepUp),
    inflationOn: Boolean(o.inflationOn),
    inflation: num(o.inflation),
  });
}

function num(v: unknown) {
  return typeof v === "number" ? v : Number.NaN;
}
