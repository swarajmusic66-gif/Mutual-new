import { useEffect, useId, useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Landmark, RotateCcw, Target, Wallet, ArrowDownToLine, Repeat } from "lucide-react";
import { clsx } from "clsx";
import {
  CURRENCIES,
  DEFAULT_INPUT,
  PRESETS,
  formatDuration,
  formatMoney,
  formatMultiple,
  formatPct,
  parseStored,
  project,
  resetInput,
  scenarioRates,
  summaryText,
  withCurrency,
  type CurrencyCode,
  type FundInput,
  type Mode,
  type Projection,
  type YearPoint,
} from "@/lib/fund";

const STORAGE_KEY = "mf-calc-v1";

const MODES: { id: Mode; label: string; blurb: string; icon: typeof Repeat }[] = [
  {
    id: "sip",
    label: "SIP",
    blurb: "Invest the same amount every month. You can raise it once a year.",
    icon: Repeat,
  },
  {
    id: "lumpsum",
    label: "Lump sum",
    blurb: "Invest one amount today and leave it to grow.",
    icon: Wallet,
  },
  {
    id: "swp",
    label: "Withdraw",
    blurb: "Start with a balance and take out a set amount every month.",
    icon: ArrowDownToLine,
  },
  {
    id: "goal",
    label: "Goal",
    blurb: "Pick a target and see the monthly SIP that could reach it.",
    icon: Target,
  },
];

export function FundCalculator() {
  const [input, setInput] = useState<FundInput>(DEFAULT_INPUT);
  const [hydrated, setHydrated] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    try {
      const saved = parseStored(JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "null"));
      if (saved) setInput(saved);
    } catch {
      /* keep defaults */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(input));
  }, [input, hydrated]);

  const result = useMemo(() => project(input), [input]);
  const rates = useMemo(() => scenarioRates(input.rate), [input.rate]);
  const scenarios = useMemo(
    () => rates.map((rate) => ({ rate, result: project(input, rate) })),
    [input, rates],
  );

  const mode = MODES.find((m) => m.id === input.mode) ?? MODES[0];
  const empty = isEmpty(input);

  function patch(partial: Partial<FundInput>) {
    setInput((prev) => ({ ...prev, ...partial }));
    setCopied(false);
  }

  async function copySummary() {
    try {
      await navigator.clipboard.writeText(summaryText(input, result));
      setCopied(true);
    } catch {
      setCopied(false);
    }
  }

  return (
    <main className="mx-auto w-full max-w-5xl px-4 py-8 sm:px-6 sm:py-12">
      <header className="mb-8 max-w-2xl">
        <p className="mb-2 flex items-center gap-2 text-sm font-medium text-muted">
          <Landmark className="size-4" aria-hidden />
          Learning tool
        </p>
        <h1 className="font-display text-4xl tracking-tight text-ink sm:text-5xl">
          Mutual fund calculator
        </h1>
        <p className="mt-3 max-w-xl text-base leading-normal text-muted">
          See how a steady monthly plan, a one-time investment, or a withdrawal
          schedule could grow. The return you type is an assumption, not a forecast.
        </p>
      </header>

      <div className="grid min-w-0 items-start gap-4 lg:grid-cols-[22rem_minmax(0,1fr)]">
        <section
          aria-label="Calculator inputs"
          className="order-2 min-w-0 rounded-xl border border-line bg-card p-5 shadow-panel lg:sticky lg:top-4 lg:order-1 lg:panel-max lg:overflow-y-auto"
        >
          <div className="mb-4 flex items-center justify-between gap-3">
            <h2 className="font-display text-2xl text-ink">Plan</h2>
            <label className="sr-only" htmlFor="currency">
              Currency
            </label>
            <select
              id="currency"
              value={input.currency}
              onChange={(e) => {
                setCopied(false);
                setInput((prev) => withCurrency(prev, e.target.value as CurrencyCode));
              }}
              className="h-11 rounded-sm border border-line bg-card px-3 text-sm font-medium text-ink"
            >
              {CURRENCIES.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.label}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-2" role="group" aria-label="Plan type">
            {MODES.map((item) => {
              const Icon = item.icon;
              const selected = item.id === input.mode;
              return (
                <button
                  key={item.id}
                  type="button"
                  aria-pressed={selected}
                  onClick={() => patch({ mode: item.id })}
                  className={clsx(
                    "flex min-h-11 items-center justify-center gap-2 rounded-sm border px-2 text-sm font-medium transition-colors duration-150",
                    selected
                      ? "border-accent bg-accent text-accent-fg"
                      : "border-line bg-card text-ink hover:border-line-strong",
                  )}
                >
                  <Icon className="size-4" aria-hidden />
                  {item.label}
                </button>
              );
            })}
          </div>
          <p className="mt-3 text-sm leading-normal text-muted">{mode.blurb}</p>

          <div className="mt-5 flex flex-col gap-4">
            {input.mode === "sip" && (
              <MoneyField
                label="Monthly investment"
                value={input.sip}
                max={PRESETS[input.currency].sipMax}
                step={PRESETS[input.currency].step}
                currency={input.currency}
                onChange={(sip) => patch({ sip })}
              />
            )}
            {input.mode === "lumpsum" && (
              <MoneyField
                label="Amount invested today"
                value={input.lumpsum}
                max={PRESETS[input.currency].lumpsumMax}
                step={PRESETS[input.currency].step * 10}
                currency={input.currency}
                onChange={(lumpsum) => patch({ lumpsum })}
              />
            )}
            {input.mode === "swp" && (
              <>
                <MoneyField
                  label="Starting amount"
                  value={input.corpus}
                  max={PRESETS[input.currency].corpusMax}
                  step={PRESETS[input.currency].step * 20}
                  currency={input.currency}
                  onChange={(corpus) => patch({ corpus })}
                />
                <MoneyField
                  label="Monthly withdrawal"
                  value={input.withdrawal}
                  max={PRESETS[input.currency].withdrawalMax}
                  step={PRESETS[input.currency].step}
                  currency={input.currency}
                  onChange={(withdrawal) => patch({ withdrawal })}
                />
              </>
            )}
            {input.mode === "goal" && (
              <MoneyField
                label="Target amount"
                value={input.target}
                max={PRESETS[input.currency].targetMax}
                step={PRESETS[input.currency].step * 20}
                currency={input.currency}
                onChange={(target) => patch({ target })}
              />
            )}

            <PercentField
              label="Expected return each year"
              hint="A planning rate. Equity funds are often sketched around 10–12% over long periods, but that is not guaranteed."
              value={input.rate}
              max={30}
              step={0.5}
              onChange={(rate) => patch({ rate })}
            />
            <div className="grid grid-cols-4 gap-2">
              {[8, 10, 12, 15].map((rate) => (
                <button
                  key={rate}
                  type="button"
                  onClick={() => patch({ rate })}
                  aria-pressed={input.rate === rate}
                  className={clsx(
                    "h-11 rounded-sm border text-sm font-medium tabular-nums",
                    input.rate === rate
                      ? "border-accent bg-accent text-accent-fg"
                      : "border-line text-ink hover:border-line-strong",
                  )}
                >
                  {rate}%
                </button>
              ))}
            </div>

            <PercentField
              label="Years"
              value={input.years}
              max={40}
              min={1}
              step={1}
              suffix="yr"
              onChange={(years) => patch({ years })}
            />
            <div className="grid grid-cols-5 gap-2">
              {[5, 10, 15, 20, 30].map((years) => (
                <button
                  key={years}
                  type="button"
                  onClick={() => patch({ years })}
                  aria-pressed={input.years === years}
                  className={clsx(
                    "h-11 rounded-sm border text-sm font-medium tabular-nums",
                    input.years === years
                      ? "border-accent bg-accent text-accent-fg"
                      : "border-line text-ink hover:border-line-strong",
                  )}
                >
                  {years}
                </button>
              ))}
            </div>

            {(input.mode === "sip" || input.mode === "goal") && (
              <PercentField
                label="Yearly step-up"
                hint="How much the monthly amount rises at the start of each new year. Use 0 to keep it flat."
                value={input.stepUp}
                max={25}
                step={1}
                onChange={(stepUp) => patch({ stepUp })}
              />
            )}

            <button
              type="button"
              role="switch"
              aria-checked={input.inflationOn}
              onClick={() => patch({ inflationOn: !input.inflationOn })}
              className="flex h-11 items-center justify-between rounded-sm border border-line px-3 text-left text-sm font-medium text-ink"
            >
              Show value in today's money
              <span
                className={clsx(
                  "relative h-6 w-11 shrink-0 rounded-full transition-colors duration-150",
                  input.inflationOn ? "bg-accent" : "bg-track",
                )}
              >
                <span
                  className={clsx(
                    "absolute top-0.5 size-5 rounded-full bg-card transition-transform duration-150",
                    input.inflationOn ? "translate-x-5" : "translate-x-0.5",
                  )}
                />
              </span>
            </button>
            {input.inflationOn && (
              <PercentField
                label="Inflation each year"
                value={input.inflation}
                max={15}
                step={0.5}
                onChange={(inflation) => patch({ inflation })}
              />
            )}
          </div>

          <button
            type="button"
            onClick={() => {
              setCopied(false);
              setInput(resetInput(input.currency, input.mode));
            }}
            className="mt-5 inline-flex h-11 items-center gap-2 text-sm font-medium text-muted hover:text-ink"
          >
            <RotateCcw className="size-4" aria-hidden />
            Reset this plan
          </button>
        </section>

        <div className="order-1 flex min-w-0 flex-col gap-4 lg:order-2">
          <section
            aria-live="polite"
            className="rounded-xl border border-line bg-card p-5 shadow-panel"
          >
            {empty ? (
              <div>
                <h2 className="font-display text-3xl text-ink">Add an amount</h2>
                <p className="mt-2 text-muted">
                  Type a number or move a slider. The estimate updates as you go.
                </p>
              </div>
            ) : (
              <ResultHero
                input={input}
                result={result}
                copied={copied}
                onCopy={() => void copySummary()}
              />
            )}
          </section>

          {!empty && (
            <>
              <section aria-label="Growth chart" className="rounded-xl border border-line bg-card p-5 shadow-panel">
                <div className="mb-3 flex flex-wrap items-end justify-between gap-3">
                  <h2 className="font-display text-2xl text-ink">Over time</h2>
                  <div className="flex items-center gap-4 text-sm text-muted">
                    <Legend swatch="bg-invested" label={input.mode === "swp" ? "Withdrawn" : "Money in"} />
                    <Legend swatch="bg-accent" label={input.mode === "swp" ? "Balance" : "Value"} />
                  </div>
                </div>
                <div className="h-72 min-w-0 w-full">
                  {hydrated ? (
                    <GrowthChart input={input} points={result.points} />
                  ) : (
                    <div className="h-full w-full rounded-sm bg-canvas" />
                  )}
                </div>
              </section>

              <section aria-label="Other return rates" className="rounded-xl border border-line bg-card p-5 shadow-panel">
                <h2 className="font-display text-2xl text-ink">Same plan, other rates</h2>
                <p className="mt-1 text-sm text-muted">
                  A small change in the yearly rate moves the result a lot over time.
                </p>
                <div className="mt-4 grid gap-2 sm:grid-cols-3">
                  {scenarios.map((item) => {
                    const active = item.rate === input.rate;
                    const figure =
                      input.mode === "goal"
                        ? formatMoney(item.result.monthlySip ?? 0, input.currency, { compact: true })
                        : input.mode === "swp"
                          ? item.result.depleted
                            ? formatDuration(item.result.months)
                            : formatMoney(item.result.value, input.currency, { compact: true })
                          : formatMoney(item.result.value, input.currency, { compact: true });
                    const caption =
                      input.mode === "goal"
                        ? "monthly SIP"
                        : input.mode === "swp"
                          ? item.result.depleted
                            ? "until it runs out"
                            : "left at the end"
                          : "estimated value";
                    return (
                      <button
                        key={item.rate}
                        type="button"
                        onClick={() => patch({ rate: item.rate })}
                        className={clsx(
                          "rounded-sm border px-3 py-3 text-left",
                          active ? "border-accent bg-canvas" : "border-line hover:border-line-strong",
                        )}
                      >
                        <p className="text-sm font-medium text-muted">{formatPct(item.rate)} a year</p>
                        <p className="mt-1 font-display text-2xl tabular-nums text-ink">{figure}</p>
                        <p className="text-sm text-faint">{caption}</p>
                      </button>
                    );
                  })}
                </div>
              </section>

              <section aria-label="Year by year" className="rounded-xl border border-line bg-card p-5 shadow-panel">
                <h2 className="font-display text-2xl text-ink">Year by year</h2>
                <div className="mt-4 min-w-0 overflow-x-auto">
                  <table className="w-full text-left text-sm">
                    <thead>
                      <tr className="border-b border-line text-muted">
                        <th className="py-2 pr-3 font-medium">Year</th>
                        <th className="py-2 pr-3 font-medium">Money in</th>
                        {input.mode === "swp" && <th className="py-2 pr-3 font-medium">Withdrawn</th>}
                        <th className="py-2 pr-3 font-medium">
                          {input.mode === "swp" ? "Balance" : "Value"}
                        </th>
                        <th className="py-2 font-medium">Growth</th>
                      </tr>
                    </thead>
                    <tbody>
                      {result.points.map((row) => (
                        <tr key={`${row.year}-${row.partial ? "p" : "f"}`} className="border-b border-line last:border-0">
                          <td className="py-2.5 pr-3 tabular-nums text-ink">
                            {row.year}
                            {row.partial ? " · stopped" : ""}
                          </td>
                          <td className="py-2.5 pr-3 tabular-nums" title={formatMoney(row.invested, input.currency)}>
                            {formatMoney(row.invested, input.currency, { compact: true })}
                          </td>
                          {input.mode === "swp" && (
                            <td className="py-2.5 pr-3 tabular-nums" title={formatMoney(row.withdrawn, input.currency)}>
                              {formatMoney(row.withdrawn, input.currency, { compact: true })}
                            </td>
                          )}
                          <td className="py-2.5 pr-3 tabular-nums" title={formatMoney(row.value, input.currency)}>
                            {formatMoney(row.value, input.currency, { compact: true })}
                          </td>
                          <td
                            className={clsx(
                              "py-2.5 tabular-nums",
                              row.value + row.withdrawn - row.invested > 0 ? "text-gain" : "text-ink",
                            )}
                            title={formatMoney(row.value + row.withdrawn - row.invested, input.currency)}
                          >
                            {formatMoney(row.value + row.withdrawn - row.invested, input.currency, { compact: true })}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>
            </>
          )}

          <details className="rounded-xl border border-line bg-card p-5 shadow-panel">
            <summary className="cursor-pointer text-sm font-medium text-ink">How the numbers are worked out</summary>
            <div className="mt-3 space-y-2 text-sm leading-normal text-muted">
              <p>
                SIP adds the monthly amount at the start of each month, then grows the whole balance by
                the yearly rate divided by 12. A step-up raises that monthly amount at the start of each
                new year.
              </p>
              <p>A lump sum starts as one amount and compounds the same way, with nothing extra added.</p>
              <p>
                A withdrawal grows the balance for the month, then takes the monthly amount. If the
                balance cannot cover it, the plan stops.
              </p>
              <p>
                The goal search finds the smallest whole-currency monthly SIP that reaches your target
                under those SIP rules. Today's money divides the ending value by inflation compounded
                over the years.
              </p>
            </div>
          </details>

          <p className="px-1 text-sm leading-normal text-faint">
            For learning only. Real mutual funds do not return the same amount every month. Markets rise
            and fall, costs vary, and past averages are not a promise. Talk with a parent or another
            trusted adult before investing money.
          </p>
        </div>
      </div>
    </main>
  );
}

function isEmpty(input: FundInput) {
  if (input.mode === "sip") return input.sip <= 0;
  if (input.mode === "lumpsum") return input.lumpsum <= 0;
  if (input.mode === "swp") return input.corpus <= 0;
  return input.target <= 0;
}

function ResultHero({
  input,
  result,
  copied,
  onCopy,
}: {
  input: FundInput;
  result: Projection;
  copied: boolean;
  onCopy: () => void;
}) {
  const c = input.currency;
  const primary =
    input.mode === "swp" && result.depleted
      ? { text: formatDuration(result.months), title: formatDuration(result.months) }
      : displayMoney(input.mode === "goal" ? (result.monthlySip ?? 0) : result.value, c);
  const growthTone = result.growth > 0 ? "text-gain" : result.growth < 0 ? "text-spend" : "text-ink";
  const share =
    result.invested > 0
      ? Math.min(100, Math.max(0, (result.invested / (result.invested + Math.max(result.growth, 0))) * 100))
      : 0;
  const headline = heroCopy(input, result);
  const tiles = [
    { label: "Money in", value: formatMoney(result.invested, c) },
    { label: "Estimated growth", value: formatMoney(result.growth, c), tone: growthTone },
  ];
  if (input.mode === "swp") tiles.push({ label: "Withdrawn", value: formatMoney(result.withdrawn, c), tone: "text-ink" });
  if (input.mode === "goal") tiles.push({ label: "Ending value", value: formatMoney(result.value, c), tone: "text-ink" });

  return (
    <div>
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-muted">{headline.label}</p>
          <p className="mt-1 font-display text-4xl tracking-tight text-ink tabular-nums sm:text-5xl" title={primary.title}>
            {primary.text}
          </p>
        </div>
        <button
          type="button"
          onClick={onCopy}
          className="h-11 shrink-0 rounded-sm border border-line px-3 text-sm font-medium text-ink hover:border-line-strong"
        >
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
      <p className="mt-3 text-sm leading-normal text-muted">{headline.detail}</p>
      {input.inflationOn && (
        <p className="mt-1 text-sm text-muted">
          About {formatMoney(result.realValue, c)} in today's money if prices rise {formatPct(input.inflation)} a
          year.
        </p>
      )}

      {input.mode !== "swp" && result.invested > 0 && result.growth >= 0 && (
        <div className="mt-4">
          <div className="flex h-2 overflow-hidden rounded-full bg-track" aria-hidden>
            <div className="h-full bg-invested" style={{ width: `${share}%` }} />
            <div className="h-full bg-accent" style={{ width: `${100 - share}%` }} />
          </div>
          <p className="mt-2 text-sm text-faint">{formatMultiple(result.value, result.invested)} the money put in</p>
        </div>
      )}

      <dl className={clsx("mt-5 grid grid-cols-2 gap-2", tiles.length > 2 && "sm:grid-cols-3")}>
        {tiles.map((tile) => (
          <Stat key={tile.label} label={tile.label} value={tile.value} tone={tile.tone} />
        ))}
      </dl>
    </div>
  );
}

function displayMoney(amount: number, currency: CurrencyCode) {
  const full = formatMoney(amount, currency);
  return {
    text: full.length > 18 ? formatMoney(amount, currency, { compact: true }) : full,
    title: full,
  };
}

function heroCopy(input: FundInput, result: Projection) {
  const c = input.currency;
  if (input.mode === "goal") {
    return {
      label: "Monthly SIP to start",
      detail:
        input.stepUp > 0
          ? `Rises ${formatPct(input.stepUp)} each year, aiming for ${formatMoney(input.target, c)} in ${input.years} years at ${formatPct(input.rate)}.`
          : `The same amount each month, aiming for ${formatMoney(input.target, c)} in ${input.years} years at ${formatPct(input.rate)}.`,
    };
  }
  if (input.mode === "swp") {
    if (result.depleted) {
      return {
        label: "Withdrawals last about",
        detail: `The balance runs out before the ${input.years}-year plan ends. ${formatMoney(result.withdrawn, c)} is taken out in total.`,
      };
    }
    return {
      label: `Left after ${input.years} ${input.years === 1 ? "year" : "years"}`,
      detail: `${formatMoney(result.withdrawn, c)} withdrawn, with money still left.`,
    };
  }
  return {
    label: "Estimated value",
    detail:
      input.mode === "sip" && input.stepUp > 0
        ? `${formatMoney(input.sip, c)} a month to start, rising ${formatPct(input.stepUp)} a year, for ${input.years} years at ${formatPct(input.rate)}.`
        : input.mode === "sip"
          ? `${formatMoney(input.sip, c)} every month for ${input.years} years at ${formatPct(input.rate)} a year.`
          : `${formatMoney(input.lumpsum, c)} invested once, left for ${input.years} years at ${formatPct(input.rate)} a year.`,
  };
}

function Stat({ label, value, tone }: { label: string; value: string; tone?: string }) {
  return (
    <div className="rounded-sm bg-canvas px-3 py-3">
      <dt className="text-sm text-muted">{label}</dt>
      <dd className={clsx("mt-1 text-base font-medium tabular-nums", tone ?? "text-ink")}>{value}</dd>
    </div>
  );
}

function Legend({ swatch, label }: { swatch: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-2">
      <span className={clsx("size-2.5 rounded-full", swatch)} aria-hidden />
      {label}
    </span>
  );
}

function GrowthChart({ input, points }: { input: FundInput; points: YearPoint[] }) {
  const reduce =
    typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const swp = input.mode === "swp";
  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart data={points} margin={{ top: 8, right: 4, left: 0, bottom: 0 }}>
        <CartesianGrid stroke="var(--color-line)" vertical={false} />
        <XAxis
          dataKey="year"
          tickFormatter={(y: number) => String(y)}
          tick={{ fill: "var(--color-faint)", fontSize: 12 }}
          axisLine={false}
          tickLine={false}
        />
        <YAxis
          width={64}
          tickFormatter={(v: number) => formatMoney(v, input.currency, { compact: true })}
          tick={{ fill: "var(--color-faint)", fontSize: 12 }}
          axisLine={false}
          tickLine={false}
        />
        <Tooltip content={<ChartTip currency={input.currency} swp={swp} />} />
        <Area
          type="monotone"
          dataKey={swp ? "withdrawn" : "invested"}
          stroke="var(--color-invested)"
          fill="var(--color-invested)"
          fillOpacity={0.18}
          strokeWidth={2}
          isAnimationActive={!reduce}
        />
        <Area
          type="monotone"
          dataKey="value"
          stroke="var(--color-accent)"
          fill="var(--color-accent)"
          fillOpacity={0.14}
          strokeWidth={2}
          isAnimationActive={!reduce}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

function ChartTip({
  active,
  payload,
  currency,
  swp,
}: {
  active?: boolean;
  payload?: Array<{ payload: YearPoint }>;
  currency: CurrencyCode;
  swp: boolean;
}) {
  if (!active || !payload?.length) return null;
  const row = payload[0]?.payload;
  if (!row) return null;
  return (
    <div className="rounded-sm border border-line bg-card px-3 py-2 text-sm shadow-panel">
      <p className="font-medium text-ink">Year {row.year}</p>
      <p className="text-muted">Money in {formatMoney(row.invested, currency)}</p>
      {swp && <p className="text-muted">Withdrawn {formatMoney(row.withdrawn, currency)}</p>}
      <p className="text-ink">Value {formatMoney(row.value, currency)}</p>
    </div>
  );
}

function MoneyField({
  label,
  value,
  onChange,
  currency,
  max,
  step,
}: {
  label: string;
  value: number;
  onChange: (n: number) => void;
  currency: CurrencyCode;
  max: number;
  step: number;
}) {
  const id = useId();
  const symbol = CURRENCIES.find((c) => c.code === currency)?.label.slice(0, 1) ?? "";
  return (
    <div>
      <label htmlFor={id} className="mb-2 block text-sm font-medium text-ink">
        {label}
      </label>
      <NumberBox
        id={id}
        value={value}
        min={0}
        max={1_000_000_000_000}
        decimals={0}
        prefix={symbol}
        onChange={onChange}
      />
      <input
        type="range"
        aria-label={label}
        min={0}
        max={Math.max(max, value)}
        step={step}
        value={Math.min(value, Math.max(max, value))}
        onChange={(e) => onChange(Number(e.target.value))}
      />
    </div>
  );
}

function PercentField({
  label,
  hint,
  value,
  onChange,
  min = 0,
  max,
  step,
  suffix = "%",
}: {
  label: string;
  hint?: string;
  value: number;
  onChange: (n: number) => void;
  min?: number;
  max: number;
  step: number;
  suffix?: string;
}) {
  const id = useId();
  return (
    <div>
      <label htmlFor={id} className="mb-2 block text-sm font-medium text-ink">
        {label}
      </label>
      <NumberBox
        id={id}
        value={value}
        min={min}
        max={max}
        decimals={step < 1 ? 1 : 0}
        suffix={suffix}
        onChange={onChange}
      />
      <input
        type="range"
        aria-label={label}
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
      />
      {hint ? <p className="text-sm leading-normal text-faint">{hint}</p> : null}
    </div>
  );
}

function NumberBox({
  id,
  value,
  onChange,
  min,
  max,
  decimals,
  prefix,
  suffix,
}: {
  id: string;
  value: number;
  onChange: (n: number) => void;
  min: number;
  max: number;
  decimals: number;
  prefix?: string;
  suffix?: string;
}) {
  const [draft, setDraft] = useState<string | null>(null);
  useEffect(() => {
    setDraft(null);
  }, [value]);

  const shown =
    draft ??
    (decimals > 0 && !Number.isInteger(value) ? value.toFixed(decimals) : String(Math.round(value)));

  function commit(raw: string) {
    const cleaned = raw.replace(/,/g, "").trim();
    const parsed = cleaned === "" || cleaned === "." || cleaned === "-" ? min : Number(cleaned);
    const n = Number.isFinite(parsed) ? parsed : min;
    const factor = 10 ** decimals;
    const rounded = Math.round(n * factor) / factor;
    onChange(Math.min(max, Math.max(min, rounded)));
    setDraft(null);
  }

  return (
    <div className="flex h-11 items-center gap-2 rounded-sm border border-line bg-card px-3 focus-within:border-accent">
      {prefix ? <span className="text-muted">{prefix}</span> : null}
      <input
        id={id}
        inputMode="decimal"
        className="w-full bg-transparent text-ink tabular-nums outline-none"
        value={shown}
        onFocus={() => setDraft(decimals > 0 ? String(value) : String(Math.round(value)))}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={() => commit(draft ?? shown)}
        onKeyDown={(e) => {
          if (e.key === "Enter") (e.currentTarget as HTMLInputElement).blur();
        }}
      />
      {suffix ? <span className="text-sm text-muted">{suffix}</span> : null}
    </div>
  );
}
