import { createFileRoute } from "@tanstack/react-router";
import { FundCalculator } from "@/components/fund-calculator";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <FundCalculator />;
}
