import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Repeat, i as RotateCcw, o as Landmark, r as Target, s as ArrowDownToLine, t as Wallet } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { a as CartesianGrid, i as Area, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Cu41YlM8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CURRENCIES = [
	{
		code: "INR",
		label: "₹ INR",
		locale: "en-IN"
	},
	{
		code: "USD",
		label: "$ USD",
		locale: "en-US"
	},
	{
		code: "EUR",
		label: "€ EUR",
		locale: "de-DE"
	},
	{
		code: "GBP",
		label: "£ GBP",
		locale: "en-GB"
	}
];
var PRESETS = {
	INR: {
		sip: 5e3,
		sipMax: 1e5,
		lumpsum: 1e5,
		lumpsumMax: 5e6,
		corpus: 25e5,
		corpusMax: 2e7,
		withdrawal: 2e4,
		withdrawalMax: 2e5,
		target: 1e7,
		targetMax: 5e7,
		step: 500
	},
	USD: {
		sip: 200,
		sipMax: 5e3,
		lumpsum: 1e4,
		lumpsumMax: 25e4,
		corpus: 1e5,
		corpusMax: 2e6,
		withdrawal: 800,
		withdrawalMax: 1e4,
		target: 5e5,
		targetMax: 5e6,
		step: 25
	},
	EUR: {
		sip: 200,
		sipMax: 5e3,
		lumpsum: 1e4,
		lumpsumMax: 25e4,
		corpus: 1e5,
		corpusMax: 2e6,
		withdrawal: 800,
		withdrawalMax: 1e4,
		target: 5e5,
		targetMax: 5e6,
		step: 25
	},
	GBP: {
		sip: 150,
		sipMax: 4e3,
		lumpsum: 8e3,
		lumpsumMax: 2e5,
		corpus: 8e4,
		corpusMax: 15e5,
		withdrawal: 600,
		withdrawalMax: 8e3,
		target: 4e5,
		targetMax: 4e6,
		step: 25
	}
};
var DEFAULT_INPUT = {
	mode: "sip",
	currency: "INR",
	...pickAmounts("INR"),
	rate: 12,
	years: 10,
	stepUp: 0,
	inflationOn: false,
	inflation: 6
};
function pickAmounts(code) {
	const p = PRESETS[code];
	return {
		sip: p.sip,
		lumpsum: p.lumpsum,
		corpus: p.corpus,
		withdrawal: p.withdrawal,
		target: p.target
	};
}
function withCurrency(input, currency) {
	return {
		...input,
		currency,
		...pickAmounts(currency)
	};
}
function resetInput(currency, mode) {
	return {
		...DEFAULT_INPUT,
		currency,
		mode,
		...pickAmounts(currency)
	};
}
var HARD_MAX = 0xe8d4a51000;
function clampInput(input) {
	return {
		...input,
		sip: clamp(input.sip, 0, HARD_MAX),
		lumpsum: clamp(input.lumpsum, 0, HARD_MAX),
		corpus: clamp(input.corpus, 0, HARD_MAX),
		withdrawal: clamp(input.withdrawal, 0, HARD_MAX),
		target: clamp(input.target, 0, HARD_MAX),
		rate: clamp(input.rate, 0, 30),
		years: Math.round(clamp(input.years, 1, 40)),
		stepUp: clamp(input.stepUp, 0, 25),
		inflation: clamp(input.inflation, 0, 15)
	};
}
function clamp(n, min, max) {
	if (!Number.isFinite(n)) return min;
	return Math.min(max, Math.max(min, n));
}
function monthlyRate(annualPct) {
	return annualPct / 100 / 12;
}
function roundMoney(n) {
	return Math.round(n);
}
/** SIP: contribution at the start of the month, then one month of growth. */
function simulateSip(monthly, annualPct, years, stepUpPct) {
	const i = monthlyRate(annualPct);
	const months = years * 12;
	let value = 0;
	let invested = 0;
	const points = [{
		year: 0,
		invested: 0,
		value: 0,
		withdrawn: 0,
		partial: false
	}];
	for (let m = 1; m <= months; m++) {
		const yearIndex = Math.floor((m - 1) / 12);
		const pmt = monthly * (1 + stepUpPct / 100) ** yearIndex;
		value = (value + pmt) * (1 + i);
		invested += pmt;
		if (m % 12 === 0) points.push({
			year: m / 12,
			invested: roundMoney(invested),
			value: roundMoney(value),
			withdrawn: 0,
			partial: false
		});
	}
	return {
		invested,
		value,
		points
	};
}
/** Lump sum: monthly compounding, no new contributions. */
function simulateLumpsum(principal, annualPct, years) {
	const i = monthlyRate(annualPct);
	const months = years * 12;
	let value = principal;
	const points = [{
		year: 0,
		invested: roundMoney(principal),
		value: roundMoney(principal),
		withdrawn: 0,
		partial: false
	}];
	for (let m = 1; m <= months; m++) {
		value *= 1 + i;
		if (m % 12 === 0) points.push({
			year: m / 12,
			invested: roundMoney(principal),
			value: roundMoney(value),
			withdrawn: 0,
			partial: false
		});
	}
	return {
		invested: principal,
		value,
		points
	};
}
/**
* Withdrawal: balance grows for the month, then the withdrawal is taken.
* Stops early if the balance cannot cover a full withdrawal.
*/
function simulateSwp(corpus, withdrawal, annualPct, years) {
	const i = monthlyRate(annualPct);
	const months = years * 12;
	let value = corpus;
	let withdrawn = 0;
	let depleted = false;
	let monthsRun = 0;
	const points = [{
		year: 0,
		invested: roundMoney(corpus),
		value: roundMoney(corpus),
		withdrawn: 0,
		partial: false
	}];
	for (let m = 1; m <= months; m++) {
		value *= 1 + i;
		const take = Math.min(Math.max(withdrawal, 0), Math.max(value, 0));
		value -= take;
		withdrawn += take;
		const short = withdrawal > 0 && take + .005 < withdrawal;
		if (value <= .005 || short) {
			value = 0;
			depleted = true;
		}
		monthsRun = m;
		if (m % 12 === 0 || depleted) points.push({
			year: Math.ceil(m / 12),
			invested: roundMoney(corpus),
			value: roundMoney(value),
			withdrawn: roundMoney(withdrawn),
			partial: depleted && m % 12 !== 0
		});
		if (depleted) break;
	}
	return {
		invested: corpus,
		value,
		withdrawn,
		depleted,
		monthsRun,
		points
	};
}
function requiredSip(target, annualPct, years, stepUpPct) {
	if (target <= 0) return 0;
	let lo = 0;
	let hi = target;
	for (let k = 0; k < 80; k++) {
		const mid = (lo + hi) / 2;
		if (simulateSip(mid, annualPct, years, stepUpPct).value >= target) hi = mid;
		else lo = mid;
	}
	return Math.ceil(hi);
}
function project(raw, rateOverride) {
	const input = clampInput(raw);
	const rate = rateOverride ?? input.rate;
	const inflation = input.inflationOn ? input.inflation : 0;
	let invested = 0;
	let value = 0;
	let withdrawn = 0;
	let months = input.years * 12;
	let depleted = false;
	let monthlySip = null;
	let points = [];
	if (input.mode === "sip") {
		const sim = simulateSip(input.sip, rate, input.years, input.stepUp);
		invested = sim.invested;
		value = sim.value;
		points = sim.points;
	} else if (input.mode === "lumpsum") {
		const sim = simulateLumpsum(input.lumpsum, rate, input.years);
		invested = sim.invested;
		value = sim.value;
		points = sim.points;
	} else if (input.mode === "swp") {
		const sim = simulateSwp(input.corpus, input.withdrawal, rate, input.years);
		invested = sim.invested;
		value = sim.value;
		withdrawn = sim.withdrawn;
		months = sim.monthsRun;
		depleted = sim.depleted;
		points = sim.points;
	} else {
		monthlySip = requiredSip(input.target, rate, input.years, input.stepUp);
		const sim = simulateSip(monthlySip, rate, input.years, input.stepUp);
		invested = sim.invested;
		value = sim.value;
		points = sim.points;
	}
	invested = roundMoney(invested);
	value = roundMoney(value);
	withdrawn = roundMoney(withdrawn);
	const growth = value + withdrawn - invested;
	const realValue = roundMoney(value / (1 + inflation / 100) ** input.years);
	return {
		mode: input.mode,
		invested,
		value,
		withdrawn,
		growth,
		months,
		depleted,
		monthlySip,
		realValue,
		points
	};
}
function scenarioRates(rate) {
	const current = Math.round(rate * 10) / 10;
	return [.../* @__PURE__ */ new Set([
		8,
		current,
		15
	])].sort((a, b) => a - b);
}
function formatMoney(value, code, opts) {
	const cur = CURRENCIES.find((c) => c.code === code) ?? CURRENCIES[0];
	const sign = value < 0 ? "-" : "";
	const abs = Math.abs(value);
	if (opts?.compact) {
		const scaled = compactParts(abs, code);
		if (scaled) {
			const num = new Intl.NumberFormat(cur.locale, {
				minimumFractionDigits: 0,
				maximumFractionDigits: scaled.digits
			}).format(scaled.n);
			return `${sign}${symbol(code)}${num}${scaled.suffix}`;
		}
	}
	return new Intl.NumberFormat(cur.locale, {
		style: "currency",
		currency: code,
		maximumFractionDigits: 0
	}).format(value);
}
function symbol(code) {
	if (code === "INR") return "₹";
	if (code === "USD") return "$";
	if (code === "EUR") return "€";
	return "£";
}
function compactParts(abs, code) {
	const units = code === "INR" ? [{
		v: 1e7,
		s: " Cr"
	}, {
		v: 1e5,
		s: " L"
	}] : [
		{
			v: 1e9,
			s: "B"
		},
		{
			v: 1e6,
			s: "M"
		},
		{
			v: 1e3,
			s: "K"
		}
	];
	for (const u of units) if (abs >= u.v) {
		const n = abs / u.v;
		const digits = n >= 100 ? 0 : n >= 10 ? 1 : 1;
		return {
			n,
			suffix: u.s,
			digits
		};
	}
	return null;
}
function formatPct(n) {
	const rounded = Math.round(n * 10) / 10;
	return Number.isInteger(rounded) ? `${rounded}%` : `${rounded.toFixed(1)}%`;
}
function formatDuration(months) {
	const safe = Math.max(0, Math.round(months));
	const y = Math.floor(safe / 12);
	const m = safe % 12;
	const parts = [];
	if (y) parts.push(`${y} ${y === 1 ? "year" : "years"}`);
	if (m) parts.push(`${m} ${m === 1 ? "month" : "months"}`);
	return parts.join(" ") || "0 months";
}
function formatMultiple(value, invested) {
	if (invested <= 0) return "—";
	const mult = value / invested;
	const digits = mult >= 10 ? 1 : 2;
	return `${mult.toFixed(digits)}×`;
}
function summaryText(input, result) {
	const c = input.currency;
	const lines = ["Mutual fund estimate (steady return, for learning)"];
	if (input.mode === "sip") {
		lines.push(`Monthly SIP: ${formatMoney(input.sip, c)}`);
		if (input.stepUp > 0) lines.push(`Yearly step-up: ${formatPct(input.stepUp)}`);
	} else if (input.mode === "lumpsum") lines.push(`Lump sum: ${formatMoney(input.lumpsum, c)}`);
	else if (input.mode === "swp") {
		lines.push(`Starting amount: ${formatMoney(input.corpus, c)}`);
		lines.push(`Monthly withdrawal: ${formatMoney(input.withdrawal, c)}`);
	} else {
		lines.push(`Target: ${formatMoney(input.target, c)}`);
		lines.push(`Monthly SIP needed: ${formatMoney(result.monthlySip ?? 0, c)}`);
		if (input.stepUp > 0) lines.push(`Yearly step-up: ${formatPct(input.stepUp)}`);
	}
	lines.push(`Assumed return: ${formatPct(input.rate)} a year`);
	lines.push(`Time: ${input.years} ${input.years === 1 ? "year" : "years"}`);
	lines.push(`Money in: ${formatMoney(result.invested, c)}`);
	if (result.withdrawn > 0) lines.push(`Withdrawn: ${formatMoney(result.withdrawn, c)}`);
	lines.push(`Estimated value: ${formatMoney(result.value, c)}`);
	lines.push(`Estimated growth: ${formatMoney(result.growth, c)}`);
	if (input.mode === "swp" && result.depleted) lines.push(`Withdrawals last about ${formatDuration(result.months)}.`);
	lines.push("Not a promise. Real mutual fund returns move up and down.");
	return lines.join("\n");
}
var MODES$1 = [
	"sip",
	"lumpsum",
	"swp",
	"goal"
];
function parseStored(raw) {
	if (!raw || typeof raw !== "object") return null;
	const o = raw;
	if (!o.mode || !MODES$1.includes(o.mode)) return null;
	if (!o.currency || !CURRENCIES.some((c) => c.code === o.currency)) return null;
	return clampInput({
		mode: o.mode,
		currency: o.currency,
		sip: num(o.sip),
		lumpsum: num(o.lumpsum),
		corpus: num(o.corpus),
		withdrawal: num(o.withdrawal),
		target: num(o.target),
		rate: num(o.rate),
		years: num(o.years),
		stepUp: num(o.stepUp),
		inflationOn: Boolean(o.inflationOn),
		inflation: num(o.inflation)
	});
}
function num(v) {
	return typeof v === "number" ? v : NaN;
}
var STORAGE_KEY = "mf-calc-v1";
var MODES = [
	{
		id: "sip",
		label: "SIP",
		blurb: "Invest the same amount every month. You can raise it once a year.",
		icon: Repeat
	},
	{
		id: "lumpsum",
		label: "Lump sum",
		blurb: "Invest one amount today and leave it to grow.",
		icon: Wallet
	},
	{
		id: "swp",
		label: "Withdraw",
		blurb: "Start with a balance and take out a set amount every month.",
		icon: ArrowDownToLine
	},
	{
		id: "goal",
		label: "Goal",
		blurb: "Pick a target and see the monthly SIP that could reach it.",
		icon: Target
	}
];
function FundCalculator() {
	const [input, setInput] = (0, import_react.useState)(DEFAULT_INPUT);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			const saved = parseStored(JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "null"));
			if (saved) setInput(saved);
		} catch {}
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		localStorage.setItem(STORAGE_KEY, JSON.stringify(input));
	}, [input, hydrated]);
	const result = (0, import_react.useMemo)(() => project(input), [input]);
	const rates = (0, import_react.useMemo)(() => scenarioRates(input.rate), [input.rate]);
	const scenarios = (0, import_react.useMemo)(() => rates.map((rate) => ({
		rate,
		result: project(input, rate)
	})), [input, rates]);
	const mode = MODES.find((m) => m.id === input.mode) ?? MODES[0];
	const empty = isEmpty(input);
	function patch(partial) {
		setInput((prev) => ({
			...prev,
			...partial
		}));
		setCopied(false);
	}
	async function copySummary() {
		try {
			await navigator.clipboard.writeText(summaryText(input, result));
			setCopied(true);
		} catch {
			setCopied(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-5xl px-4 py-8 sm:px-6 sm:py-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-8 max-w-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-2 flex items-center gap-2 text-sm font-medium text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, {
						className: "size-4",
						"aria-hidden": true
					}), "Learning tool"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl tracking-tight text-ink sm:text-5xl",
					children: "Mutual fund calculator"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-xl text-base leading-normal text-muted",
					children: "See how a steady monthly plan, a one-time investment, or a withdrawal schedule could grow. The return you type is an assumption, not a forecast."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid min-w-0 items-start gap-4 lg:grid-cols-[22rem_minmax(0,1fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-label": "Calculator inputs",
				className: "order-2 min-w-0 rounded-xl border border-line bg-card p-5 shadow-panel lg:sticky lg:top-4 lg:order-1 lg:panel-max lg:overflow-y-auto",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex items-center justify-between gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl text-ink",
								children: "Plan"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "sr-only",
								htmlFor: "currency",
								children: "Currency"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								id: "currency",
								value: input.currency,
								onChange: (e) => {
									setCopied(false);
									setInput((prev) => withCurrency(prev, e.target.value));
								},
								className: "h-11 rounded-sm border border-line bg-card px-3 text-sm font-medium text-ink",
								children: CURRENCIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: c.code,
									children: c.label
								}, c.code))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						role: "group",
						"aria-label": "Plan type",
						children: MODES.map((item) => {
							const Icon = item.icon;
							const selected = item.id === input.mode;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-pressed": selected,
								onClick: () => patch({ mode: item.id }),
								className: clsx("flex min-h-11 items-center justify-center gap-2 rounded-sm border px-2 text-sm font-medium transition-colors duration-150", selected ? "border-accent bg-accent text-accent-fg" : "border-line bg-card text-ink hover:border-line-strong"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-4",
									"aria-hidden": true
								}), item.label]
							}, item.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-normal text-muted",
						children: mode.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex flex-col gap-4",
						children: [
							input.mode === "sip" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyField, {
								label: "Monthly investment",
								value: input.sip,
								max: PRESETS[input.currency].sipMax,
								step: PRESETS[input.currency].step,
								currency: input.currency,
								onChange: (sip) => patch({ sip })
							}),
							input.mode === "lumpsum" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyField, {
								label: "Amount invested today",
								value: input.lumpsum,
								max: PRESETS[input.currency].lumpsumMax,
								step: PRESETS[input.currency].step * 10,
								currency: input.currency,
								onChange: (lumpsum) => patch({ lumpsum })
							}),
							input.mode === "swp" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyField, {
								label: "Starting amount",
								value: input.corpus,
								max: PRESETS[input.currency].corpusMax,
								step: PRESETS[input.currency].step * 20,
								currency: input.currency,
								onChange: (corpus) => patch({ corpus })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyField, {
								label: "Monthly withdrawal",
								value: input.withdrawal,
								max: PRESETS[input.currency].withdrawalMax,
								step: PRESETS[input.currency].step,
								currency: input.currency,
								onChange: (withdrawal) => patch({ withdrawal })
							})] }),
							input.mode === "goal" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyField, {
								label: "Target amount",
								value: input.target,
								max: PRESETS[input.currency].targetMax,
								step: PRESETS[input.currency].step * 20,
								currency: input.currency,
								onChange: (target) => patch({ target })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PercentField, {
								label: "Expected return each year",
								hint: "A planning rate. Equity funds are often sketched around 10–12% over long periods, but that is not guaranteed.",
								value: input.rate,
								max: 30,
								step: .5,
								onChange: (rate) => patch({ rate })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-4 gap-2",
								children: [
									8,
									10,
									12,
									15
								].map((rate) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => patch({ rate }),
									"aria-pressed": input.rate === rate,
									className: clsx("h-11 rounded-sm border text-sm font-medium tabular-nums", input.rate === rate ? "border-accent bg-accent text-accent-fg" : "border-line text-ink hover:border-line-strong"),
									children: [rate, "%"]
								}, rate))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PercentField, {
								label: "Years",
								value: input.years,
								max: 40,
								min: 1,
								step: 1,
								suffix: "yr",
								onChange: (years) => patch({ years })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-5 gap-2",
								children: [
									5,
									10,
									15,
									20,
									30
								].map((years) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => patch({ years }),
									"aria-pressed": input.years === years,
									className: clsx("h-11 rounded-sm border text-sm font-medium tabular-nums", input.years === years ? "border-accent bg-accent text-accent-fg" : "border-line text-ink hover:border-line-strong"),
									children: years
								}, years))
							}),
							(input.mode === "sip" || input.mode === "goal") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PercentField, {
								label: "Yearly step-up",
								hint: "How much the monthly amount rises at the start of each new year. Use 0 to keep it flat.",
								value: input.stepUp,
								max: 25,
								step: 1,
								onChange: (stepUp) => patch({ stepUp })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								role: "switch",
								"aria-checked": input.inflationOn,
								onClick: () => patch({ inflationOn: !input.inflationOn }),
								className: "flex h-11 items-center justify-between rounded-sm border border-line px-3 text-left text-sm font-medium text-ink",
								children: ["Show value in today's money", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: clsx("relative h-6 w-11 shrink-0 rounded-full transition-colors duration-150", input.inflationOn ? "bg-accent" : "bg-track"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: clsx("absolute top-0.5 size-5 rounded-full bg-card transition-transform duration-150", input.inflationOn ? "translate-x-5" : "translate-x-0.5") })
								})]
							}),
							input.inflationOn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PercentField, {
								label: "Inflation each year",
								value: input.inflation,
								max: 15,
								step: .5,
								onChange: (inflation) => patch({ inflation })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setCopied(false);
							setInput(resetInput(input.currency, input.mode));
						},
						className: "mt-5 inline-flex h-11 items-center gap-2 text-sm font-medium text-muted hover:text-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
							className: "size-4",
							"aria-hidden": true
						}), "Reset this plan"]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "order-1 flex min-w-0 flex-col gap-4 lg:order-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						"aria-live": "polite",
						className: "rounded-xl border border-line bg-card p-5 shadow-panel",
						children: empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl text-ink",
							children: "Add an amount"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-muted",
							children: "Type a number or move a slider. The estimate updates as you go."
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultHero, {
							input,
							result,
							copied,
							onCopy: () => void copySummary()
						})
					}),
					!empty && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							"aria-label": "Growth chart",
							className: "rounded-xl border border-line bg-card p-5 shadow-panel",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3 flex flex-wrap items-end justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-2xl text-ink",
									children: "Over time"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-4 text-sm text-muted",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
										swatch: "bg-invested",
										label: input.mode === "swp" ? "Withdrawn" : "Money in"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
										swatch: "bg-accent",
										label: input.mode === "swp" ? "Balance" : "Value"
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-72 min-w-0 w-full",
								children: hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GrowthChart, {
									input,
									points: result.points
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-full rounded-sm bg-canvas" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							"aria-label": "Other return rates",
							className: "rounded-xl border border-line bg-card p-5 shadow-panel",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-2xl text-ink",
									children: "Same plan, other rates"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: "A small change in the yearly rate moves the result a lot over time."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4 grid gap-2 sm:grid-cols-3",
									children: scenarios.map((item) => {
										const active = item.rate === input.rate;
										const figure = input.mode === "goal" ? formatMoney(item.result.monthlySip ?? 0, input.currency, { compact: true }) : input.mode === "swp" ? item.result.depleted ? formatDuration(item.result.months) : formatMoney(item.result.value, input.currency, { compact: true }) : formatMoney(item.result.value, input.currency, { compact: true });
										const caption = input.mode === "goal" ? "monthly SIP" : input.mode === "swp" ? item.result.depleted ? "until it runs out" : "left at the end" : "estimated value";
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => patch({ rate: item.rate }),
											className: clsx("rounded-sm border px-3 py-3 text-left", active ? "border-accent bg-canvas" : "border-line hover:border-line-strong"),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-sm font-medium text-muted",
													children: [formatPct(item.rate), " a year"]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-1 font-display text-2xl tabular-nums text-ink",
													children: figure
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm text-faint",
													children: caption
												})
											]
										}, item.rate);
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							"aria-label": "Year by year",
							className: "rounded-xl border border-line bg-card p-5 shadow-panel",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl text-ink",
								children: "Year by year"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 min-w-0 overflow-x-auto",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full text-left text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b border-line text-muted",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-2 pr-3 font-medium",
												children: "Year"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-2 pr-3 font-medium",
												children: "Money in"
											}),
											input.mode === "swp" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-2 pr-3 font-medium",
												children: "Withdrawn"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-2 pr-3 font-medium",
												children: input.mode === "swp" ? "Balance" : "Value"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-2 font-medium",
												children: "Growth"
											})
										]
									}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: result.points.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b border-line last:border-0",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "py-2.5 pr-3 tabular-nums text-ink",
												children: [row.year, row.partial ? " · stopped" : ""]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "py-2.5 pr-3 tabular-nums",
												title: formatMoney(row.invested, input.currency),
												children: formatMoney(row.invested, input.currency, { compact: true })
											}),
											input.mode === "swp" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "py-2.5 pr-3 tabular-nums",
												title: formatMoney(row.withdrawn, input.currency),
												children: formatMoney(row.withdrawn, input.currency, { compact: true })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "py-2.5 pr-3 tabular-nums",
												title: formatMoney(row.value, input.currency),
												children: formatMoney(row.value, input.currency, { compact: true })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: clsx("py-2.5 tabular-nums", row.value + row.withdrawn - row.invested > 0 ? "text-gain" : "text-ink"),
												title: formatMoney(row.value + row.withdrawn - row.invested, input.currency),
												children: formatMoney(row.value + row.withdrawn - row.invested, input.currency, { compact: true })
											})
										]
									}, `${row.year}-${row.partial ? "p" : "f"}`)) })]
								})
							})]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
						className: "rounded-xl border border-line bg-card p-5 shadow-panel",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
							className: "cursor-pointer text-sm font-medium text-ink",
							children: "How the numbers are worked out"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 space-y-2 text-sm leading-normal text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "SIP adds the monthly amount at the start of each month, then grows the whole balance by the yearly rate divided by 12. A step-up raises that monthly amount at the start of each new year." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A lump sum starts as one amount and compounds the same way, with nothing extra added." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A withdrawal grows the balance for the month, then takes the monthly amount. If the balance cannot cover it, the plan stops." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The goal search finds the smallest whole-currency monthly SIP that reaches your target under those SIP rules. Today's money divides the ending value by inflation compounded over the years." })
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-1 text-sm leading-normal text-faint",
						children: "For learning only. Real mutual funds do not return the same amount every month. Markets rise and fall, costs vary, and past averages are not a promise. Talk with a parent or another trusted adult before investing money."
					})
				]
			})]
		})]
	});
}
function isEmpty(input) {
	if (input.mode === "sip") return input.sip <= 0;
	if (input.mode === "lumpsum") return input.lumpsum <= 0;
	if (input.mode === "swp") return input.corpus <= 0;
	return input.target <= 0;
}
function ResultHero({ input, result, copied, onCopy }) {
	const c = input.currency;
	const primary = input.mode === "swp" && result.depleted ? {
		text: formatDuration(result.months),
		title: formatDuration(result.months)
	} : displayMoney(input.mode === "goal" ? result.monthlySip ?? 0 : result.value, c);
	const growthTone = result.growth > 0 ? "text-gain" : result.growth < 0 ? "text-spend" : "text-ink";
	const share = result.invested > 0 ? Math.min(100, Math.max(0, result.invested / (result.invested + Math.max(result.growth, 0)) * 100)) : 0;
	const headline = heroCopy(input, result);
	const tiles = [{
		label: "Money in",
		value: formatMoney(result.invested, c)
	}, {
		label: "Estimated growth",
		value: formatMoney(result.growth, c),
		tone: growthTone
	}];
	if (input.mode === "swp") tiles.push({
		label: "Withdrawn",
		value: formatMoney(result.withdrawn, c),
		tone: "text-ink"
	});
	if (input.mode === "goal") tiles.push({
		label: "Ending value",
		value: formatMoney(result.value, c),
		tone: "text-ink"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-muted",
				children: headline.label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-4xl tracking-tight text-ink tabular-nums sm:text-5xl",
				title: primary.title,
				children: primary.text
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onCopy,
				className: "h-11 shrink-0 rounded-sm border border-line px-3 text-sm font-medium text-ink hover:border-line-strong",
				children: copied ? "Copied" : "Copy"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm leading-normal text-muted",
			children: headline.detail
		}),
		input.inflationOn && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-sm text-muted",
			children: [
				"About ",
				formatMoney(result.realValue, c),
				" in today's money if prices rise ",
				formatPct(input.inflation),
				" a year."
			]
		}),
		input.mode !== "swp" && result.invested > 0 && result.growth >= 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-2 overflow-hidden rounded-full bg-track",
				"aria-hidden": true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full bg-invested",
					style: { width: `${share}%` }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full bg-accent",
					style: { width: `${100 - share}%` }
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-faint",
				children: [formatMultiple(result.value, result.invested), " the money put in"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
			className: clsx("mt-5 grid grid-cols-2 gap-2", tiles.length > 2 && "sm:grid-cols-3"),
			children: tiles.map((tile) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: tile.label,
				value: tile.value,
				tone: tile.tone
			}, tile.label))
		})
	] });
}
function displayMoney(amount, currency) {
	const full = formatMoney(amount, currency);
	return {
		text: full.length > 18 ? formatMoney(amount, currency, { compact: true }) : full,
		title: full
	};
}
function heroCopy(input, result) {
	const c = input.currency;
	if (input.mode === "goal") return {
		label: "Monthly SIP to start",
		detail: input.stepUp > 0 ? `Rises ${formatPct(input.stepUp)} each year, aiming for ${formatMoney(input.target, c)} in ${input.years} years at ${formatPct(input.rate)}.` : `The same amount each month, aiming for ${formatMoney(input.target, c)} in ${input.years} years at ${formatPct(input.rate)}.`
	};
	if (input.mode === "swp") {
		if (result.depleted) return {
			label: "Withdrawals last about",
			detail: `The balance runs out before the ${input.years}-year plan ends. ${formatMoney(result.withdrawn, c)} is taken out in total.`
		};
		return {
			label: `Left after ${input.years} ${input.years === 1 ? "year" : "years"}`,
			detail: `${formatMoney(result.withdrawn, c)} withdrawn, with money still left.`
		};
	}
	return {
		label: "Estimated value",
		detail: input.mode === "sip" && input.stepUp > 0 ? `${formatMoney(input.sip, c)} a month to start, rising ${formatPct(input.stepUp)} a year, for ${input.years} years at ${formatPct(input.rate)}.` : input.mode === "sip" ? `${formatMoney(input.sip, c)} every month for ${input.years} years at ${formatPct(input.rate)} a year.` : `${formatMoney(input.lumpsum, c)} invested once, left for ${input.years} years at ${formatPct(input.rate)} a year.`
	};
}
function Stat({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-sm bg-canvas px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: clsx("mt-1 text-base font-medium tabular-nums", tone ?? "text-ink"),
			children: value
		})]
	});
}
function Legend({ swatch, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: clsx("size-2.5 rounded-full", swatch),
			"aria-hidden": true
		}), label]
	});
}
function GrowthChart({ input, points }) {
	const reduce = typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
	const swp = input.mode === "swp";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
		width: "100%",
		height: "100%",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
			data: points,
			margin: {
				top: 8,
				right: 4,
				left: 0,
				bottom: 0
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
					stroke: "var(--color-line)",
					vertical: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					dataKey: "year",
					tickFormatter: (y) => String(y),
					tick: {
						fill: "var(--color-faint)",
						fontSize: 12
					},
					axisLine: false,
					tickLine: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
					width: 64,
					tickFormatter: (v) => formatMoney(v, input.currency, { compact: true }),
					tick: {
						fill: "var(--color-faint)",
						fontSize: 12
					},
					axisLine: false,
					tickLine: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, {
					currency: input.currency,
					swp
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					type: "monotone",
					dataKey: swp ? "withdrawn" : "invested",
					stroke: "var(--color-invested)",
					fill: "var(--color-invested)",
					fillOpacity: .18,
					strokeWidth: 2,
					isAnimationActive: !reduce
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					type: "monotone",
					dataKey: "value",
					stroke: "var(--color-accent)",
					fill: "var(--color-accent)",
					fillOpacity: .14,
					strokeWidth: 2,
					isAnimationActive: !reduce
				})
			]
		})
	});
}
function ChartTip({ active, payload, currency, swp }) {
	if (!active || !payload?.length) return null;
	const row = payload[0]?.payload;
	if (!row) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-sm border border-line bg-card px-3 py-2 text-sm shadow-panel",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-medium text-ink",
				children: ["Year ", row.year]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-muted",
				children: ["Money in ", formatMoney(row.invested, currency)]
			}),
			swp && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-muted",
				children: ["Withdrawn ", formatMoney(row.withdrawn, currency)]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-ink",
				children: ["Value ", formatMoney(row.value, currency)]
			})
		]
	});
}
function MoneyField({ label, value, onChange, currency, max, step }) {
	const id = (0, import_react.useId)();
	const symbol = CURRENCIES.find((c) => c.code === currency)?.label.slice(0, 1) ?? "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			htmlFor: id,
			className: "mb-2 block text-sm font-medium text-ink",
			children: label
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberBox, {
			id,
			value,
			min: 0,
			max: 0xe8d4a51000,
			decimals: 0,
			prefix: symbol,
			onChange
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "range",
			"aria-label": label,
			min: 0,
			max: Math.max(max, value),
			step,
			value: Math.min(value, Math.max(max, value)),
			onChange: (e) => onChange(Number(e.target.value))
		})
	] });
}
function PercentField({ label, hint, value, onChange, min = 0, max, step, suffix = "%" }) {
	const id = (0, import_react.useId)();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			htmlFor: id,
			className: "mb-2 block text-sm font-medium text-ink",
			children: label
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberBox, {
			id,
			value,
			min,
			max,
			decimals: step < 1 ? 1 : 0,
			suffix,
			onChange
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "range",
			"aria-label": label,
			min,
			max,
			step,
			value,
			onChange: (e) => onChange(Number(e.target.value))
		}),
		hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-normal text-faint",
			children: hint
		}) : null
	] });
}
function NumberBox({ id, value, onChange, min, max, decimals, prefix, suffix }) {
	const [draft, setDraft] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setDraft(null);
	}, [value]);
	const shown = draft ?? (decimals > 0 && !Number.isInteger(value) ? value.toFixed(decimals) : String(Math.round(value)));
	function commit(raw) {
		const cleaned = raw.replace(/,/g, "").trim();
		const parsed = cleaned === "" || cleaned === "." || cleaned === "-" ? min : Number(cleaned);
		const n = Number.isFinite(parsed) ? parsed : min;
		const factor = 10 ** decimals;
		const rounded = Math.round(n * factor) / factor;
		onChange(Math.min(max, Math.max(min, rounded)));
		setDraft(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-11 items-center gap-2 rounded-sm border border-line bg-card px-3 focus-within:border-accent",
		children: [
			prefix ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted",
				children: prefix
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id,
				inputMode: "decimal",
				className: "w-full bg-transparent text-ink tabular-nums outline-none",
				value: shown,
				onFocus: () => setDraft(decimals > 0 ? String(value) : String(Math.round(value))),
				onChange: (e) => setDraft(e.target.value),
				onBlur: () => commit(draft ?? shown),
				onKeyDown: (e) => {
					if (e.key === "Enter") e.currentTarget.blur();
				}
			}),
			suffix ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm text-muted",
				children: suffix
			}) : null
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FundCalculator, {});
}
//#endregion
export { Home as component };
